libpe
=====

The PE library

[![Build Status](https://travis-ci.org/merces/libpe.png)](https://travis-ci.org/merces/libpe)

