pev
===

The PE file analysis toolkit

[![Build Status](https://travis-ci.org/merces/pev.png)](https://travis-ci.org/merces/pev)
