#ifndef STRLCAT_H
#define STRLCAT_H

#include <stddef.h>

size_t bsd_strlcat(char *dst, const char *src, size_t siz);

#endif
